package com.roaaempsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoaaEmpSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoaaEmpSystemApplication.class, args);
	}

}
